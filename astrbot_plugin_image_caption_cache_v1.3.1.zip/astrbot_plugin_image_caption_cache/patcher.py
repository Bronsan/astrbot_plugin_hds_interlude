from __future__ import annotations

import functools
import importlib
import inspect
import os
from collections.abc import Callable
from types import ModuleType
from typing import Any

try:
    from .cache import ImageCaptionCache
except ImportError:
    from cache import ImageCaptionCache


PatchRecord = tuple[ModuleType | type, str, str, Any]

QUOTE_CAPTION_PROMPT = "Please describe the image content."

# Optional parameters understood by each wrapper. A signature that contains
# fewer of them (older AstrBot) or more (newer AstrBot) is still supported:
# every replacement accepts ``*args, **kwargs`` and binds the call against the
# original signature, so unknown additions never surface as a TypeError.
_KNOWN_QUOTE_PARAMS = frozenset(
    {
        "quoted_message_settings",
        "main_provider_supports_image",
        "skip_quote_image_caption",
        "image_ref",
        "image_is_montage",
        "config",
    }
)
_KNOWN_DECORATE_PARAMS = frozenset({"provider", "montage_refs"})
_KNOWN_CAPTION_PARAMS = frozenset({"prompt", "montage_refs"})


class ImageCaptionCachePatcher:
    def __init__(
        self,
        *,
        cache: ImageCaptionCache,
        ttl_resolver: Callable[[object | None], int],
        logger: Any,
    ) -> None:
        self._cache = cache
        self._ttl_resolver = ttl_resolver
        self._logger = logger
        self._patches: list[PatchRecord] = []

    def apply(
        self,
        *,
        patch_main_agent: bool = True,
        patch_quoted_message: bool = True,
        force_caption_for_vision_models: bool = True,
    ) -> list[str]:
        applied = []
        if patch_main_agent and self._patch_main_agent_request():
            applied.append("main_agent")
            if (
                force_caption_for_vision_models
                and self._patch_native_vision_caption()
            ):
                applied.append("native_vision")
        if patch_quoted_message and self._patch_quoted_message():
            applied.append("quoted_message")
        return applied

    def restore(self) -> None:
        for target, name, original_attr, replacement in reversed(self._patches):
            if getattr(target, name, None) is replacement and hasattr(
                target, original_attr
            ):
                setattr(target, name, getattr(target, original_attr))
                delattr(target, original_attr)
        self._patches.clear()

    def _patch_main_agent_request(self) -> bool:
        ama = self._import_module("astrbot.core.astr_main_agent")
        if ama is None or not hasattr(ama, "_request_img_caption"):
            return False

        original = getattr(ama, "_request_img_caption")
        if not self._signature_compatible(
            original,
            ["provider_id", "cfg", "image_urls", "plugin_context"],
            _KNOWN_CAPTION_PARAMS,
        ):
            self._logger.warning(
                "Skip image caption cache patch: unsupported "
                "_request_img_caption signature %s.",
                self._describe_signature(original),
            )
            return False

        @functools.wraps(original)
        async def cached_request_img_caption(*args: Any, **kwargs: Any) -> str:
            bound = self._bind_arguments(original, args, kwargs)
            if bound is None:
                return await original(*args, **kwargs)

            provider_id = str(bound.get("provider_id") or "")
            cfg = bound.get("cfg")
            if not isinstance(cfg, dict):
                cfg = {}
            image_urls = [str(url) for url in (bound.get("image_urls") or [])]
            plugin_context = bound.get("plugin_context")

            provider = plugin_context.get_provider_by_id(provider_id)
            provider_cls = getattr(ama, "Provider", None)
            if provider is None:
                raise ValueError(
                    "Cannot get image caption because provider "
                    f"`{provider_id}` does not exist."
                )
            if provider_cls is not None and not isinstance(provider, provider_cls):
                raise ValueError(
                    "Cannot get image caption because provider "
                    f"`{provider_id}` is not a valid Provider, it is {type(provider)}."
                )

            caption_prompt = self._request_caption_prompt(
                ama,
                cfg,
                image_urls=image_urls,
                montage_refs=bound.get("montage_refs"),
                prompt=bound.get("prompt"),
            )
            cache_provider_id = self._resolve_provider_cache_identity(
                provider,
                configured_provider_id=provider_id,
            )
            ttl = self._ttl_resolver(cfg)

            async def caption_factory() -> str:
                return await self._call_visual_model(
                    provider,
                    provider_identity=cache_provider_id,
                    prompt=caption_prompt,
                    image_urls=image_urls,
                )

            return await self._cache.get_or_create(
                provider_id=cache_provider_id,
                prompt=caption_prompt,
                image_urls=list(image_urls),
                ttl_seconds=ttl,
                caption_factory=caption_factory,
            )

        self._replace(
            ama,
            "_request_img_caption",
            cached_request_img_caption,
            "__image_caption_cache_original_request_img_caption",
        )
        return True

    def _patch_native_vision_caption(self) -> bool:
        ama = self._import_module("astrbot.core.astr_main_agent")
        if ama is None or not hasattr(ama, "_decorate_llm_request"):
            return False

        original = getattr(ama, "_decorate_llm_request")
        if not self._signature_compatible(
            original,
            ["event", "req", "plugin_context", "config"],
            _KNOWN_DECORATE_PARAMS,
        ):
            self._logger.warning(
                "Skip native vision caption cache patch: unsupported "
                "_decorate_llm_request signature %s.",
                self._describe_signature(original),
            )
            return False
        if "provider" not in self._parameter_names(original):
            # AstrBot <= 4.25 cannot tell whether the main model sees images,
            # so the forced-caption branch has nothing to decide on. The
            # cached _request_img_caption patch still covers that layout.
            self._logger.info(
                "Skip native vision caption cache patch: _decorate_llm_request "
                "does not expose a provider argument."
            )
            return False

        @functools.wraps(original)
        async def cached_decorate_llm_request(*args: Any, **kwargs: Any) -> Any:
            bound = self._bind_arguments(original, args, kwargs)
            if bound is None:
                return await original(*args, **kwargs)

            event = bound.get("event")
            req = bound.get("req")
            plugin_context = bound.get("plugin_context")
            config = bound.get("config")
            provider = bound.get("provider")
            montage_refs = bound.get("montage_refs")

            captioned_refs: set[str] = set()
            try:
                provider_settings = self._provider_settings(
                    event,
                    plugin_context,
                    config,
                )
                image_caption_provider_id = (
                    provider_settings.get("default_image_caption_provider_id") or ""
                )
                provider_supports_image = (
                    provider is not None
                    and hasattr(ama, "_provider_supports_modality")
                    and ama._provider_supports_modality(provider, "image")
                )
                if (
                    req is not None
                    and getattr(req, "conversation", None)
                    and getattr(req, "image_urls", None)
                    and image_caption_provider_id
                    and provider_supports_image
                ):
                    self._logger.debug(
                        "Main provider supports image input; forcing cached image "
                        "captioning with the configured caption provider."
                    )
                    ensure_caption = getattr(ama, "_ensure_img_caption", None)
                    if callable(ensure_caption):
                        if (
                            montage_refs is not None
                            and self._signature_accepts(ensure_caption, "montage_refs")
                        ):
                            result = await ensure_caption(
                                event,
                                req,
                                provider_settings,
                                plugin_context,
                                image_caption_provider_id,
                                montage_refs=montage_refs,
                            )
                        else:
                            result = await ensure_caption(
                                event,
                                req,
                                provider_settings,
                                plugin_context,
                                image_caption_provider_id,
                            )
                        if isinstance(result, set):
                            captioned_refs.update(str(ref) for ref in result)
            except Exception as exc:
                # Keep the original request flow alive: a failed forced caption
                # must never abort the whole LLM request.
                self._logger.error(
                    f"Failed to force cached image captioning: {exc}"
                )

            result = await original(*args, **kwargs)
            # AstrBot 4.29+ returns the set of captioned references and feeds it
            # back into the image preparation stage; older versions return None.
            if isinstance(result, set):
                return captioned_refs | result
            return result

        self._replace(
            ama,
            "_decorate_llm_request",
            cached_decorate_llm_request,
            "__image_caption_cache_original_decorate_llm_request",
        )
        return True

    def _patch_quoted_message(self) -> bool:
        ama = self._import_module("astrbot.core.astr_main_agent")
        if ama is None or not hasattr(ama, "_process_quote_message"):
            return False

        original = getattr(ama, "_process_quote_message")
        if not self._signature_compatible(
            original,
            ["event", "req", "img_cap_prov_id", "plugin_context"],
            _KNOWN_QUOTE_PARAMS,
        ):
            self._logger.warning(
                "Skip quoted image caption cache patch: unsupported "
                "_process_quote_message signature %s.",
                self._describe_signature(original),
            )
            return False

        # AstrBot >= 4.28 hands over an already prepared image reference and no
        # longer reads images from the quote chain; older releases only expose
        # the quote chain. Both layouts are served by the same wrapper.
        prepared_image_mode = "image_ref" in self._parameter_names(original)
        mode = "prepared-image" if prepared_image_mode else "legacy-quote-chain"
        self._logger.info(
            "image_caption_cache: patching _process_quote_message "
            f"(mode={mode}, signature={self._describe_signature(original)})."
        )

        @functools.wraps(original)
        async def cached_process_quote_message(*args: Any, **kwargs: Any) -> Any:
            bound = self._bind_arguments(original, args, kwargs)
            if bound is None:
                return await original(*args, **kwargs)

            event = bound.get("event")
            req = bound.get("req")
            img_cap_prov_id = str(bound.get("img_cap_prov_id") or "")
            plugin_context = bound.get("plugin_context")
            quoted_message_settings = bound.get("quoted_message_settings")
            main_provider_supports_image = bool(
                bound.get("main_provider_supports_image", False)
            )
            skip_quote_image_caption = bool(
                bound.get("skip_quote_image_caption", False)
            )
            image_ref = bound.get("image_ref")
            image_is_montage = bool(bound.get("image_is_montage", False))
            config = bound.get("config")

            quote = None
            message_chain = getattr(
                getattr(event, "message_obj", None),
                "message",
                None,
            )
            for comp in message_chain or []:
                if isinstance(comp, ama.Reply):
                    quote = comp
                    break
            if not quote:
                return None

            content_parts = []
            sender_info = (
                f"({quote.sender_nickname}): " if quote.sender_nickname else ""
            )
            if quoted_message_settings is None:
                quoted_message_settings = getattr(
                    ama,
                    "DEFAULT_QUOTED_MESSAGE_SETTINGS",
                    None,
                )
            if quoted_message_settings is None:
                message_str = await ama.extract_quoted_message_text(event, quote)
            else:
                message_str = await ama.extract_quoted_message_text(
                    event,
                    quote,
                    settings=quoted_message_settings,
                )
            message_str = message_str or quote.message_str or "[Empty Text]"
            content_parts.append(f"{sender_info}{message_str}")

            captioned_ref = None
            if prepared_image_mode:
                if image_ref:
                    captioned_ref = await self._capture_quoted_image(
                        ama,
                        event,
                        content_parts,
                        img_cap_prov_id=img_cap_prov_id,
                        plugin_context=plugin_context,
                        config=config,
                        image_ref=str(image_ref),
                        image_is_montage=image_is_montage,
                        main_provider_supports_image=main_provider_supports_image,
                        skip_quote_image_caption=skip_quote_image_caption,
                    )
            else:
                image_seg = None
                if quote.chain:
                    for comp in quote.chain:
                        if isinstance(comp, ama.Image):
                            image_seg = comp
                            break
                if image_seg is not None:
                    await self._capture_quoted_image(
                        ama,
                        event,
                        content_parts,
                        img_cap_prov_id=img_cap_prov_id,
                        plugin_context=plugin_context,
                        config=config,
                        image_seg=image_seg,
                        main_provider_supports_image=main_provider_supports_image,
                        skip_quote_image_caption=skip_quote_image_caption,
                    )

            quoted_content = "\n".join(content_parts)
            quoted_text = f"<Quoted Message>\n{quoted_content}\n</Quoted Message>"
            req.extra_user_content_parts.append(ama.TextPart(text=quoted_text))
            return captioned_ref

        self._replace(
            ama,
            "_process_quote_message",
            cached_process_quote_message,
            "__image_caption_cache_original_process_quote_message",
        )
        return True

    async def _capture_quoted_image(
        self,
        ama: ModuleType,
        event: Any,
        content_parts: list[str],
        *,
        img_cap_prov_id: str,
        plugin_context: Any,
        config: Any = None,
        image_ref: str | None = None,
        image_seg: Any = None,
        image_is_montage: bool = False,
        main_provider_supports_image: bool = False,
        skip_quote_image_caption: bool = False,
    ) -> str | None:
        """Caption the quoted image through the cache, matching AstrBot gating."""
        if skip_quote_image_caption:
            self._logger.debug(
                "Skipping quote image captioning because image captioning already "
                "handled this request."
            )
            return None
        if main_provider_supports_image:
            self._logger.debug(
                "Skipping quote image captioning because the main provider "
                "supports image input."
            )
            return None
        if not img_cap_prov_id:
            self._logger.debug(
                "No dedicated image caption provider configured. "
                "Skipping quote image captioning."
            )
            return None

        return await self._append_cached_quoted_image_caption(
            ama,
            event,
            content_parts,
            img_cap_prov_id=img_cap_prov_id,
            plugin_context=plugin_context,
            config=config,
            image_ref=image_ref,
            image_seg=image_seg,
            image_is_montage=image_is_montage,
        )

    async def _append_cached_quoted_image_caption(
        self,
        ama: ModuleType,
        event: Any,
        content_parts: list[str],
        *,
        img_cap_prov_id: str,
        plugin_context: Any,
        config: Any = None,
        image_ref: str | None = None,
        image_seg: Any = None,
        image_is_montage: bool = False,
    ) -> str | None:
        provider = None
        source_path = None
        compress_path = None
        try:
            provider = await self._resolve_caption_provider(
                event,
                plugin_context,
                img_cap_prov_id,
            )

            provider_cls = getattr(ama, "Provider", None)
            if not provider or (
                provider_cls is not None and not isinstance(provider, provider_cls)
            ):
                self._logger.warning("No provider found for image captioning in quote.")
                return None

            if image_ref:
                source_path = str(image_ref)
            elif image_seg is not None:
                source_path = await image_seg.convert_to_file_path()
            if not source_path:
                return None

            provider_settings = self._provider_settings(
                event,
                plugin_context,
                config,
            )
            if image_ref is None:
                # Legacy path: AstrBot <= 4.27 exposed the compression helper.
                # 4.28+ already hands over a prepared, size-bounded image and
                # dropped the helper.
                compressor = getattr(ama, "_compress_image_for_provider", None)
                if callable(compressor):
                    compress_path = await compressor(source_path, provider_settings)
                    checker = getattr(
                        ama,
                        "_is_generated_compressed_image_path",
                        None,
                    )
                    generated = compress_path != source_path
                    if callable(checker):
                        try:
                            generated = checker(source_path, compress_path)
                        except Exception:
                            generated = compress_path != source_path
                    tracker = getattr(event, "track_temporary_local_file", None)
                    if generated and callable(tracker):
                        tracker(compress_path)

            caption_prompt = QUOTE_CAPTION_PROMPT
            if image_is_montage:
                notice = getattr(ama, "ANIMATION_CAPTION_NOTICE", "")
                if isinstance(notice, str) and notice:
                    try:
                        caption_prompt += notice.format(indices="1")
                    except (KeyError, IndexError, ValueError):
                        pass

            cache_provider_id = self._resolve_provider_cache_identity(
                provider,
                configured_provider_id=img_cap_prov_id,
            )
            ttl = self._ttl_resolver(provider_settings)
            image_for_model = compress_path or source_path

            async def caption_factory() -> str:
                return await self._call_visual_model(
                    provider,
                    provider_identity=cache_provider_id,
                    prompt=caption_prompt,
                    image_urls=[image_for_model],
                )

            caption = await self._cache.get_or_create(
                provider_id=cache_provider_id,
                prompt=caption_prompt,
                image_urls=[image_for_model],
                ttl_seconds=ttl,
                caption_factory=caption_factory,
            )
            if caption:
                content_parts.append(f"[Image Caption in quoted message]: {caption}")
                if image_ref:
                    return source_path
            return None
        except Exception as exc:
            self._logger.error(f"Failed to process quoted image: {exc}")
            return None
        finally:
            if (
                compress_path
                and compress_path != source_path
                and os.path.exists(compress_path)
            ):
                try:
                    os.remove(compress_path)
                except Exception as exc:
                    self._logger.warning(
                        f"Fail to remove temporary compressed image: {exc}"
                    )

    async def _resolve_caption_provider(
        self,
        event: Any,
        plugin_context: Any,
        provider_id: str,
    ) -> Any:
        provider = plugin_context.get_provider_by_id(provider_id)
        if provider is not None:
            return provider
        umo = getattr(event, "unified_msg_origin", None)
        get_async = getattr(plugin_context, "get_using_provider_async", None)
        if callable(get_async):
            return await get_async(umo)
        return plugin_context.get_using_provider(umo)

    def _provider_settings(
        self,
        event: Any,
        plugin_context: Any,
        config: Any,
    ) -> dict:
        settings = getattr(config, "provider_settings", None)
        if isinstance(settings, dict) and settings:
            return settings
        if plugin_context is None:
            return {}
        try:
            try:
                plugin_config = plugin_context.get_config(
                    umo=getattr(event, "unified_msg_origin", None)
                )
            except TypeError:
                plugin_config = plugin_context.get_config()
        except Exception:
            return {}
        if not hasattr(plugin_config, "get"):
            return {}
        settings = plugin_config.get("provider_settings", {})
        return settings if isinstance(settings, dict) else {}

    def _request_caption_prompt(
        self,
        ama: ModuleType,
        cfg: dict,
        *,
        image_urls: list[str],
        montage_refs: Any = None,
        prompt: Any = None,
    ) -> str:
        if isinstance(prompt, str) and prompt:
            base_prompt = prompt
        else:
            base_prompt = cfg.get(
                "image_caption_prompt",
                "Please describe the image.",
            )
        montage_set = {str(ref) for ref in (montage_refs or ())}
        indices = [
            str(index)
            for index, ref in enumerate(image_urls, start=1)
            if ref in montage_set
        ]
        notice = getattr(ama, "ANIMATION_CAPTION_NOTICE", "")
        if indices and isinstance(notice, str) and notice:
            try:
                base_prompt += notice.format(indices=", ".join(indices))
            except (KeyError, IndexError, ValueError):
                pass
        return base_prompt

    async def _call_visual_model(
        self,
        provider: Any,
        *,
        provider_identity: str,
        prompt: str,
        image_urls: list[str],
    ) -> str:
        self._logger.info(
            "Image caption visual model call. "
            f"provider={provider_identity or '<default>'}, "
            f"images={len(image_urls)}"
        )
        response = await provider.text_chat(
            prompt=prompt,
            image_urls=image_urls,
        )
        return getattr(response, "completion_text", "") if response else ""

    def _replace(
        self,
        target: ModuleType | type,
        name: str,
        replacement: Any,
        original_attr: str,
    ) -> None:
        if not hasattr(target, original_attr):
            setattr(target, original_attr, getattr(target, name))
        setattr(target, name, replacement)
        self._patches.append((target, name, original_attr, replacement))

    def _import_module(self, module_name: str) -> ModuleType | None:
        try:
            return importlib.import_module(module_name)
        except Exception as exc:
            self._logger.warning(
                f"Skip image caption cache patch for {module_name}: {exc}"
            )
            return None

    def _bind_arguments(
        self,
        func: Any,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Bind a call against the original signature, tolerant of new kwargs."""
        try:
            signature = inspect.signature(func)
        except (TypeError, ValueError):
            return None
        try:
            bound = signature.bind(*args, **kwargs)
        except TypeError:
            try:
                bound = signature.bind_partial(*args, **kwargs)
            except TypeError:
                return None
        bound.apply_defaults()
        return dict(bound.arguments)

    def _signature_parameters(self, func: Any) -> list[inspect.Parameter]:
        try:
            parameters = inspect.signature(func).parameters.values()
        except (TypeError, ValueError):
            return []
        return [
            parameter
            for parameter in parameters
            if parameter.kind
            not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
        ]

    def _parameter_names(self, func: Any) -> list[str]:
        return [parameter.name for parameter in self._signature_parameters(func)]

    def _signature_accepts(self, func: Any, name: str) -> bool:
        try:
            return name in inspect.signature(func).parameters
        except (TypeError, ValueError):
            return False

    def _signature_compatible(
        self,
        func: Any,
        prefix: list[str],
        known_optionals: frozenset[str],
    ) -> bool:
        """Check the positional prefix and refuse unknown required parameters.

        Wrappers can absorb arbitrary keyword arguments, but a new *required*
        parameter changes semantics the wrapper cannot honour. Skipping the
        patch keeps AstrBot working (without caching) instead of crashing at
        runtime, which is exactly the failure mode this guard prevents.
        """
        parameters = self._signature_parameters(func)
        if [parameter.name for parameter in parameters[: len(prefix)]] != prefix:
            return False
        for parameter in parameters[len(prefix) :]:
            if parameter.name in known_optionals:
                continue
            if parameter.default is inspect.Parameter.empty:
                return False
        return True

    def _describe_signature(self, func: Any) -> str:
        return "(" + ", ".join(self._parameter_names(func)) + ")"

    def _resolve_provider_cache_identity(
        self,
        provider: Any,
        *,
        configured_provider_id: str,
    ) -> str:
        provider_config = (
            provider.provider_config
            if isinstance(getattr(provider, "provider_config", None), dict)
            else {}
        )
        provider_id = provider_config.get("id") or configured_provider_id
        if provider_id:
            return str(provider_id)

        provider_type = provider_config.get("type", "")
        return ":".join(
            [
                provider.__class__.__module__,
                provider.__class__.__qualname__,
                "" if provider_type is None else str(provider_type),
            ]
        )
