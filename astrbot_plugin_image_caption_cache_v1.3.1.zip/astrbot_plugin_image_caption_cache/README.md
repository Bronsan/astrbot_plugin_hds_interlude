# astrbot_plugin_image_caption_cache

为 AstrBot 图片转述结果增加 TTL 内存缓存，参考 AstrBotDevs/AstrBot#8966 的实现思路做成外置插件。

## 功能

- 主对话图片转述缓存：同一 provider、同一提示词、同一图片在 TTL 内复用结果。
- 引用消息图片转述缓存。
- 支持 `base64://`、`data:image...`、本地文件、`file://` 和远程 URL 的图片指纹。
- 插件卸载时自动恢复被补丁覆盖的 AstrBot 核心函数。

远程图片不会被下载求哈希，缓存键使用 URL 本身；本地图片和 base64 图片使用内容哈希。

## 配置

在 AstrBot WebUI 的插件配置中设置：

- `enabled`：是否启用补丁，默认开启。
- `enable_ttl_cache`：启用 TTL 缓存策略，默认开启。
- `image_caption_cache_ttl`：缓存有效期，单位秒，默认 `600`；设为 `0` 等同关闭 TTL 策略。
- `enable_image_count_cache`：启用图片数量缓存策略，默认开启。
- `max_cached_images`：最多缓存的图片数量，默认 `200`；多图转述会按实际图片张数占用容量。
- `patch_main_agent`：缓存主对话图片转述，默认开启。
- `force_caption_for_vision_models`：主模型原生支持图片时也强制先走专用图片转述与缓存，默认开启。
- `patch_quoted_message`：缓存引用消息图片转述，默认开启。
- `fingerprint_remote_images`：远程图片使用内容指纹，默认开启；用于处理平台每次生成不同临时 URL 的情况。
- `remote_fingerprint_timeout`：远程图片内容指纹下载超时，默认 `8` 秒。
- `remote_fingerprint_max_bytes`：远程图片内容指纹最大下载字节数，默认 `20971520`。

修改配置后请重载插件。

## 命令

- `/image_caption_cache_stats`：查看当前缓存条目数、缓存图片数量、锁数量、策略开关和补丁目标。
- `/image_caption_cache_clear`：清空缓存。

## 说明

AstrBot 目前没有为外部插件暴露“图片转述前”的稳定 hook，因此本插件在构造时和 AstrBot 加载完成时都会尝试对核心函数做运行时补丁。补丁会检查目标函数签名；如果当前 AstrBot 版本接口不兼容，会跳过对应接入点并写入日志。可通过 `/image_caption_cache_stats` 查看当前补丁目标。

## 兼容性

补丁层按运行时签名自适应，覆盖 AstrBot 4.16 以来的多种函数布局：

| 接入点 | 旧布局（≤4.27） | 4.28 | 4.29+ |
| --- | --- | --- | --- |
| `_process_quote_message` | 从 `quote.chain` 取图，可带 `config` | 新增 `image_ref`（调用方传入已准备图片） | 再加 `image_is_montage`，返回已转述引用 |
| `_request_img_caption` | 4 个参数 | 4 个参数 | 新增 `montage_refs` |
| `_decorate_llm_request` | 4~5 个参数，返回 `None` | 返回 `None` | 新增 `montage_refs`，返回 `set[str]` |

替换函数统一以 `*args, **kwargs` 接收调用，再按原函数签名绑定参数，因此 AstrBot 新增关键字参数时不会再抛 `unexpected keyword argument`；`_decorate_llm_request` 会原样透传返回值（4.29 的 `captioned_refs` 集合），避免下游 `set.update(None)` 报错。

如果未来版本新增了补丁不认识且**无默认值**的必需参数，补丁会主动跳过并在日志中写明签名，而不是在运行期崩溃。

## 许可证

本项目基于 [GNU General Public License v3.0](LICENSE) 授权。
