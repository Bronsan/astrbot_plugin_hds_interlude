"""Compatibility tests for the AstrBot runtime patches.

Covers the layouts that shipped between 4.26 and 4.29:

* 4.26/4.27: ``_process_quote_message(..., config, main_provider_supports_image,
  skip_quote_image_caption)`` and quote images read from ``quote.chain``.
* 4.28: ``config`` replaced by ``image_ref``; the caller passes the prepared
  image path as a keyword argument.
* 4.29: adds ``image_is_montage``, ``montage_refs`` and set return values.

Run with: python tests/patch_compat_test.py
"""

from __future__ import annotations

import asyncio
import os
import sys
import tempfile
import types
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from cache import ImageCaptionCache  # noqa: E402
from patcher import ImageCaptionCachePatcher  # noqa: E402


class FakeLogger:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def _record(self, level: str, message: str, *args: Any) -> None:
        if args:
            try:
                message = message % args
            except TypeError:
                message = " ".join([message, *(str(arg) for arg in args)])
        self.messages.append(f"{level}:{message}")

    def debug(self, message: str, *args: Any) -> None:
        self._record("debug", message, *args)

    def info(self, message: str, *args: Any) -> None:
        self._record("info", message, *args)

    def warning(self, message: str, *args: Any) -> None:
        self._record("warning", message, *args)

    def error(self, message: str, *args: Any) -> None:
        self._record("error", message, *args)

    def contains(self, needle: str) -> bool:
        return any(needle in message for message in self.messages)


class FakeProvider:
    def __init__(self) -> None:
        self.calls: list[tuple[str, list[str]]] = []
        self.provider_config = {"id": "caption-provider"}

    async def text_chat(self, *, prompt: str, image_urls: list[str]):
        self.calls.append((prompt, list(image_urls)))
        return types.SimpleNamespace(completion_text=f"caption-{len(self.calls)}")


class FakeProviderContext:
    def __init__(self, provider: FakeProvider) -> None:
        self._provider = provider
        self._settings = {
            "provider_settings": {
                "default_image_caption_provider_id": "caption-provider",
            }
        }

    def get_provider_by_id(self, provider_id: str):
        return self._provider if provider_id == "caption-provider" else None

    async def get_using_provider_async(self, umo: str | None = None):
        return self._provider

    def get_using_provider(self, umo: str | None = None):
        return self._provider

    def get_config(self, umo: str | None = None):
        return self._settings


class Reply:
    def __init__(self, nickname: str, chain: list[Any] | None = None) -> None:
        self.sender_nickname = nickname
        self.message_str = "quoted text"
        self.chain = chain or []


class Image:
    def __init__(self, path: str) -> None:
        self.path = path

    async def convert_to_file_path(self) -> str:
        return self.path


class TextPart:
    def __init__(self, text: str) -> None:
        self.text = text


class FakeRequest:
    def __init__(self) -> None:
        self.extra_user_content_parts: list[TextPart] = []
        self.image_urls: list[str] = []
        self.conversation: Any = None

    @property
    def text(self) -> str:
        return "\n".join(part.text for part in self.extra_user_content_parts)


def build_module(layout: str):
    """Create a fake astrbot.core.astr_main_agent for the given layout."""
    module = types.ModuleType("astrbot.core.astr_main_agent")

    module.Provider = FakeProvider
    module.Reply = Reply
    module.Image = Image
    module.TextPart = TextPart
    module.DEFAULT_QUOTED_MESSAGE_SETTINGS = object()
    module.ANIMATION_CAPTION_NOTICE = "\nThis image is a montage of frames {indices}."

    async def extract_quoted_message_text(event, quote, settings=None):
        return quote.message_str

    module.extract_quoted_message_text = extract_quoted_message_text

    def _provider_supports_modality(provider, modality):
        return modality == "image" and isinstance(provider, FakeProvider)

    module._provider_supports_modality = _provider_supports_modality

    async def _request_img_caption(provider_id, cfg, image_urls, plugin_context):
        return "original-caption"

    async def _ensure_img_caption(
        event,
        req,
        cfg,
        plugin_context,
        image_caption_provider,
        montage_refs=None,
    ):
        return None

    async def _decorate_llm_request(
        event,
        req,
        plugin_context,
        config,
        provider=None,
        montage_refs=None,
    ):
        return None

    if layout == "4.29":
        async def _request_img_caption(  # noqa: F811
            provider_id,
            cfg,
            image_urls,
            plugin_context,
            montage_refs=None,
        ):
            return "original-caption"

        async def _ensure_img_caption(
            event,
            req,
            cfg,
            plugin_context,
            image_caption_provider,
            montage_refs=None,
        ):
            return set()

        async def _decorate_llm_request(
            event,
            req,
            plugin_context,
            config,
            provider=None,
            montage_refs=None,
        ):
            return {"from-original"}

        async def _process_quote_message(
            event,
            req,
            img_cap_prov_id,
            plugin_context,
            quoted_message_settings=None,
            main_provider_supports_image=False,
            skip_quote_image_caption=False,
            image_ref=None,
            image_is_montage=False,
        ):
            req.extra_user_content_parts.append(TextPart(text="original"))
            return image_ref

    elif layout == "4.28":
        async def _ensure_img_caption(
            event,
            req,
            cfg,
            plugin_context,
            image_caption_provider,
        ):
            return None

        async def _decorate_llm_request(
            event,
            req,
            plugin_context,
            config,
            provider=None,
        ):
            return None

        async def _process_quote_message(
            event,
            req,
            img_cap_prov_id,
            plugin_context,
            quoted_message_settings=None,
            main_provider_supports_image=False,
            skip_quote_image_caption=False,
            image_ref=None,
        ):
            req.extra_user_content_parts.append(TextPart(text="original"))
            return None

    elif layout == "4.27":
        async def _ensure_img_caption(
            event,
            req,
            cfg,
            plugin_context,
            image_caption_provider,
        ):
            return None

        async def _decorate_llm_request(
            event,
            req,
            plugin_context,
            config,
            provider=None,
        ):
            return None

        async def _process_quote_message(
            event,
            req,
            img_cap_prov_id,
            plugin_context,
            quoted_message_settings=None,
            config=None,
            main_provider_supports_image=False,
            skip_quote_image_caption=False,
        ):
            req.extra_user_content_parts.append(TextPart(text="original"))
            return None

    elif layout == "unknown-required":
        async def _process_quote_message(
            event,
            req,
            img_cap_prov_id,
            plugin_context,
            brand_new_required_parameter,
        ):
            return None

    else:  # pragma: no cover
        raise AssertionError(layout)

    module._request_img_caption = _request_img_caption
    module._ensure_img_caption = _ensure_img_caption
    module._decorate_llm_request = _decorate_llm_request
    module._process_quote_message = _process_quote_message

    astrbot_pkg = types.ModuleType("astrbot")
    astrbot_pkg.__path__ = []
    core_pkg = types.ModuleType("astrbot.core")
    core_pkg.__path__ = []
    sys.modules["astrbot"] = astrbot_pkg
    sys.modules["astrbot.core"] = core_pkg
    sys.modules["astrbot.core.astr_main_agent"] = module
    return module


class Event:
    def __init__(self, chain=None) -> None:
        self.message_obj = types.SimpleNamespace(message=chain or [])
        self.unified_msg_origin = "test:GroupMessage:1"
        self.tracked: list[str] = []

    def track_temporary_local_file(self, path: str) -> None:
        self.tracked.append(path)


class Config:
    def __init__(self) -> None:
        self.provider_settings = {
            "default_image_caption_provider_id": "caption-provider",
        }


def make_patcher(provider: FakeProvider):
    cache = ImageCaptionCache()
    log = FakeLogger()
    patcher = ImageCaptionCachePatcher(
        cache=cache,
        ttl_resolver=lambda cfg: 600,
        logger=log,
    )
    patcher._test_cache = cache
    patcher._test_logger = log
    patcher._test_provider = provider
    return patcher


async def test_429_quote_message(prepared_path: str) -> None:
    module = build_module("4.29")
    provider = FakeProvider()
    context = FakeProviderContext(provider)
    patcher = make_patcher(provider)
    assert patcher.apply() == ["main_agent", "native_vision", "quoted_message"]

    event = Event([Reply("alice")])
    req = FakeRequest()
    result = await module._process_quote_message(
        event,
        req,
        "caption-provider",
        context,
        module.DEFAULT_QUOTED_MESSAGE_SETTINGS,
        main_provider_supports_image=False,
        skip_quote_image_caption=False,
        image_ref=prepared_path,
        image_is_montage=False,
    )
    assert result == prepared_path, result
    assert "[Image Caption in quoted message]: caption-1" in req.text, req.text
    assert len(provider.calls) == 1

    # Second turn with the same image must be served from the cache.
    req2 = FakeRequest()
    await module._process_quote_message(
        event,
        req2,
        "caption-provider",
        context,
        module.DEFAULT_QUOTED_MESSAGE_SETTINGS,
        image_ref=prepared_path,
    )
    assert len(provider.calls) == 1, provider.calls
    assert "caption-1" in req2.text

    # Montage captions use a distinct prompt and therefore a distinct entry.
    req3 = FakeRequest()
    await module._process_quote_message(
        event,
        req3,
        "caption-provider",
        context,
        module.DEFAULT_QUOTED_MESSAGE_SETTINGS,
        image_ref=prepared_path,
        image_is_montage=True,
    )
    assert len(provider.calls) == 2, provider.calls
    assert "montage of frames 1" in provider.calls[1][0], provider.calls[1]

    # Skipping rules still mirror AstrBot.
    req4 = FakeRequest()
    assert (
        await module._process_quote_message(
            event,
            req4,
            "caption-provider",
            context,
            module.DEFAULT_QUOTED_MESSAGE_SETTINGS,
            image_ref=prepared_path,
            skip_quote_image_caption=True,
        )
        is None
    )
    assert len(provider.calls) == 2

    patcher.restore()
    assert module._process_quote_message.__name__ == "_process_quote_message"


async def test_428_quote_message(prepared_path: str) -> None:
    module = build_module("4.28")
    provider = FakeProvider()
    context = FakeProviderContext(provider)
    patcher = make_patcher(provider)
    assert patcher.apply() == ["main_agent", "native_vision", "quoted_message"]

    event = Event([Reply("bob")])
    req = FakeRequest()
    result = await module._process_quote_message(
        event,
        req,
        "caption-provider",
        context,
        module.DEFAULT_QUOTED_MESSAGE_SETTINGS,
        main_provider_supports_image=False,
        skip_quote_image_caption=False,
        image_ref=prepared_path,
    )
    # 4.28 ignores return values, returning the reference is harmless.
    assert result == prepared_path
    assert "caption-1" in req.text
    patcher.restore()


async def test_427_legacy_quote_message(prepared_path: str) -> None:
    module = build_module("4.27")
    provider = FakeProvider()
    context = FakeProviderContext(provider)
    patcher = make_patcher(provider)
    assert "quoted_message" in patcher.apply()

    event = Event([Reply("carol", chain=[Image(prepared_path)])])
    req = FakeRequest()
    result = await module._process_quote_message(
        event,
        req,
        "caption-provider",
        context,
        module.DEFAULT_QUOTED_MESSAGE_SETTINGS,
        Config(),
        main_provider_supports_image=False,
        skip_quote_image_caption=False,
    )
    assert result is None, "legacy layout must keep the original None return"
    assert "caption-1" in req.text, req.text
    assert provider.calls[0][1] == [prepared_path]
    patcher.restore()


async def test_429_request_img_caption(prepared_path: str) -> None:
    module = build_module("4.29")
    provider = FakeProvider()
    context = FakeProviderContext(provider)
    patcher = make_patcher(provider)
    patcher.apply()

    caption = await module._request_img_caption(
        "caption-provider",
        {"image_caption_prompt": "describe"},
        [prepared_path],
        context,
        montage_refs={prepared_path},
    )
    assert caption == "caption-1"
    assert "montage of frames 1" in provider.calls[0][0], provider.calls[0]
    patcher.restore()


async def test_429_decorate_llm_request(prepared_path: str) -> None:
    module = build_module("4.29")
    provider = FakeProvider()
    context = FakeProviderContext(provider)
    patcher = make_patcher(provider)
    patcher.apply()

    event = Event([Reply("dave")])
    req = FakeRequest()
    req.conversation = types.SimpleNamespace(id="conv")
    req.image_urls = [prepared_path]
    result = await module._decorate_llm_request(
        event,
        req,
        context,
        Config(),
        provider=provider,
        montage_refs={prepared_path},
    )
    assert isinstance(result, set), result
    assert "from-original" in result, result
    patcher.restore()


async def test_unknown_required_parameter_skips_patch() -> None:
    module = build_module("unknown-required")
    provider = FakeProvider()
    patcher = make_patcher(provider)
    applied = patcher.apply()
    assert applied == ["main_agent", "native_vision"], applied
    assert patcher._test_logger.contains("unsupported _process_quote_message")
    original = module._process_quote_message
    assert original.__name__ == "_process_quote_message"


async def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        path = os.path.join(tmp, "quote.jpg")
        with open(path, "wb") as handle:
            handle.write(b"fake-jpeg-bytes")

        await test_429_quote_message(path)
        await test_428_quote_message(path)
        await test_427_legacy_quote_message(path)
        await test_429_request_img_caption(path)
        await test_429_decorate_llm_request(path)
        await test_unknown_required_parameter_skips_patch()

    print("patch compatibility tests passed")


if __name__ == "__main__":
    asyncio.run(main())
